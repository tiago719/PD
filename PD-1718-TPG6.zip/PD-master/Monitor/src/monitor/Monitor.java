package monitor;

import Gui.EcraPrincipalView;
import Logic.ObservableScreen;


public class Monitor {

    public static void main(String[] args) {
        EcraPrincipalView x = new EcraPrincipalView(new ObservableScreen());
    }
    
}
