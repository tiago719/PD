/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.ComunicacaoJogo;


/**
 *
 * @author Tiago Coutinho
 */
public class Comunicacao {

    public static final int PORTO = 5001;
    public static final int PORTO2 = 5002;
    public static final int BUFSIZE = 4000;
    public static final String IP = "localhost";
    public static final int TIMEOUT = 50000;

    public Comunicacao() {
    }
    
    public void Start()
    {
        while(true)
        {
            //TODO define condicao
        }
    }
}
