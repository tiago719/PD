package classescomunicacao.ModelJogo;

public interface Constants {
    public static final int DIM = 3;
    public static final int NUM_TOKENS_TURN = 3;
    
    public static final int PORTO_SERVIDOR_GESTAO=6001;
    public static final String HOST_SERVIDOR_GESTAO="localhost"; 
}
