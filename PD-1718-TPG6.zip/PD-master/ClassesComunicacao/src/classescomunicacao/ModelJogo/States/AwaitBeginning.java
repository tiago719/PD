package classescomunicacao.ModelJogo.States;

import classescomunicacao.ModelJogo.GameData;


public class AwaitBeginning extends StateAdapter 
{
    public AwaitBeginning(GameData g) 
    {
        super(g);
    }
    
 }
