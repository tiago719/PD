package classescomunicacao;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tiago Coutinho
 */
public interface ConstantesIps
{
    public static final int PORTO = 5001;
    public static final int PORTO2 = 5002;
    public static final int PORTOSERVIDORJOGO = 6006;
}
